const Discord = require('discord.js');
const client = new Discord.Client();

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

client.on('message', msg => {
  if (msg.content === 'ping') {
    msg.reply('Pong!');
  } //    You can extend this with: else if (msg.content === 'command') {
    //    msg.reply('response');
    //    }

    //    You can repete this and make as many commands as you want.
    //    You can find a helpful guid on https://discord.js.org
});

client.login('token');