<!> I am not responsable for any damage caused by using this template, use at your own risk. <!>

Please refur to https://discord.js.org for a guid on how to code a discord js bot. This is a template for you to build off of.
In order to run this, you need to have the following installed:
1. https://nodejs.org
2. https://code.visualstudio.com
3. https://www.python.org/ (optional needed for some bots)

Check out my channel on YouTube: https://www.youtube.com/channel/UClKSKt3qQHKRql-IcGcdVwQ